class BinaryTreeNode {
  constructor(val, left = null, right = null) {
    this.val = val;
    this.left = left;
    this.right = right;
  }
}

class BinaryTree {
  constructor(root = null) {
    this.root = root;
  }

  /** minDepth(): return the minimum depth of the tree. */
  minDepth() {
    if (!this.root) return 0;

    function helper(node) {
      if (!node) return Infinity;
      if (!node.left && !node.right) return 1;
      return 1 + Math.min(helper(node.left), helper(node.right));
    }

    return helper(this.root);
  }

  /** maxDepth(): return the maximum depth of the tree. */
  maxDepth() {
    if (!this.root) return 0;

    function helper(node) {
      if (!node) return 0;
      return 1 + Math.max(helper(node.left), helper(node.right));
    }

    return helper(this.root);
  }

  /** maxSum(): return the maximum sum you can obtain by traveling along a path in the tree. */
  maxSum() {
    if (!this.root) return 0;
    let result = -Infinity;

    function helper(node) {
      if (!node) return 0;

      const left = Math.max(0, helper(node.left));
      const right = Math.max(0, helper(node.right));

      result = Math.max(result, node.val + left + right);

      return node.val + Math.max(left, right);
    }

    helper(this.root);
    return result;
  }

  /** nextLarger(lowerBound): return the smallest value in the tree larger than lowerBound. */
  nextLarger(lowerBound) {
    if (!this.root) return null;

    let queue = [this.root];
    let closest = null;

    while (queue.length) {
      let node = queue.shift();

      if (node.val > lowerBound && (closest === null || node.val < closest)) {
        closest = node.val;
      }

      if (node.left) queue.push(node.left);
      if (node.right) queue.push(node.right);
    }

    return closest;
  }

  // === areCousins(node1, node2) ===
  areCousins(node1, node2) {
    if (!this.root || !node1 || !node2) return false;

    // Helper to find level and parent of a node
    const findLevelAndParent = (root, target, level = 0, parent = null) => {
      if (!root) return null;
      if (root === target) return { level, parent };
      return (
        findLevelAndParent(root.left, target, level + 1, root) ||
        findLevelAndParent(root.right, target, level + 1, root)
      );
    };

    const node1Info = findLevelAndParent(this.root, node1);
    const node2Info = findLevelAndParent(this.root, node2);

    if (!node1Info || !node2Info) return false;

    // Cousins if same level but different parents
    return (
      node1Info.level === node2Info.level &&
      node1Info.parent !== node2Info.parent
    );
  }

  // === static serialize(tree) ===
  static serialize(tree) {
    if (!tree || !tree.root) return "";

    // Preorder traversal with null markers
    const result = [];

    const traverse = (node) => {
      if (!node) {
        result.push("null");
        return;
      }
      result.push(node.val.toString());
      traverse(node.left);
      traverse(node.right);
    };

    traverse(tree.root);
    return result.join(",");
  }

  // === static deserialize(stringTree) ===
  static deserialize(stringTree) {
    if (!stringTree) return new BinaryTree();

    const values = stringTree.split(",");
    let index = 0;

    const buildTree = () => {
      if (values[index] === "null") {
        index++;
        return null;
      }

      const node = new BinaryTreeNode(Number(values[index]));
      index++;
      node.left = buildTree();
      node.right = buildTree();
      return node;
    };

    const root = buildTree();
    return new BinaryTree(root);
  }

  // === lowestCommonAncestor(node1, node2) ===
  lowestCommonAncestor(node1, node2) {
    if (!this.root || !node1 || !node2) return null;

    // Recursive helper that returns LCA or null
    const lcaHelper = (root) => {
      if (!root) return null;
      if (root === node1 || root === node2) return root;

      const left = lcaHelper(root.left);
      const right = lcaHelper(root.right);

      if (left && right) return root;
      return left || right;
    };

    return lcaHelper(this.root);
  }
}

module.exports = { BinaryTree, BinaryTreeNode };
